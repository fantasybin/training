gulp-demo
=========

请阅读 [使用 gulp 构建一个项目](https://github.com/nimojs/gulp-book/blob/master/chapter7.md)