'use strict';

// first node program:
console.log('Hello, world!');
