xclass
======

oo support for javascript