YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "XClass",
        "XClass.utils",
        "XNative"
    ],
    "modules": [
        "xclass"
    ],
    "allModules": [
        {
            "displayName": "xclass",
            "name": "xclass"
        }
    ]
} };
});